package sv.edu.udb.desafio2_dwf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Desafio2DwfApplication {

    public static void main(String[] args) {
        SpringApplication.run(Desafio2DwfApplication.class, args);
    }

}
