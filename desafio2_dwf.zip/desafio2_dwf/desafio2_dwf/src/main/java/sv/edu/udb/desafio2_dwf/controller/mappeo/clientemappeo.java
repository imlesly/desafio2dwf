package sv.edu.udb.desafio2_dwf.controller.mappeo;
import sv.edu.udb.repository.domain.Cliente;
import sv.edu.udb.controller.request.ClienteRequest;
import sv.edu.udb.controller.response.ClienteResponse;
import org.mapstruct.Mapper;
@Mapper(componentModel = "spring", uses = {invoicemappeo.class})
public interface clientemappeo {
    clienteresponse toResponse(cliente cliente);

    cliente toEntity(clienterequest request);
}
