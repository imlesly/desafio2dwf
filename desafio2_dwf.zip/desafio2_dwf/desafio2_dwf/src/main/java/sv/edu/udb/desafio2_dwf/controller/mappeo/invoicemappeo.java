package sv.edu.udb.desafio2_dwf.controller.mappeo;

public interface invoicemappeo {
}
