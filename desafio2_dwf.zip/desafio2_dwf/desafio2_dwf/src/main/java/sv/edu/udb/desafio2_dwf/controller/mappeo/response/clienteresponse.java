package sv.edu.udb.desafio2_dwf.controller.mappeo.response;
import lombok.Data;
        @Data
public class clienteresponse {
            private long id;
            private String producto;
            private Double monto;
            private Double iva;
            private Double totalmonto;
}
