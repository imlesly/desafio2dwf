package sv.edu.udb.desafio2_dwf.controller.mappeo.response;

public class invoiceresponse {
}
