package sv.edu.udb.desafio2_dwf.repository;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Invoice { @Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
    private String producto; // el nombre de el producto que vs s comprar el cliente
    private Double monto; // el precio normal del producto que va a comprar el cliente
    private Double iva;  // en este caso el producto tiene un impuesto en este caso el IVA tiene el valor del 13%
    private Double totalmonto; // esto es el precio normar del producto ya con el iva incluido
 @ManyToOne //se utiliza cuando hay muchos de datos de un solo objeto en este caso seria que el cliente tiene muchas facturaa
    @JoinColumn(name = "id_cliente")// esto pertenece a la base de datos pero lo que quiere decir es que la informacion de la factura se va a guardar
    //con la llave foreana con el nombre de id_cliente
 private cliente clientefactura;
}
