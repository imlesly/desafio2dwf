package sv.edu.udb.desafio2_dwf.repository.domain;

public interface clienterepository {
}
