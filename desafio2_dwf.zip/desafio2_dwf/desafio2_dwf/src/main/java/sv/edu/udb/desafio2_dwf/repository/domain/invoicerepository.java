package sv.edu.udb.desafio2_dwf.repository.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface invoicerepository extends JpaRepository<invoice, Long>{
}
