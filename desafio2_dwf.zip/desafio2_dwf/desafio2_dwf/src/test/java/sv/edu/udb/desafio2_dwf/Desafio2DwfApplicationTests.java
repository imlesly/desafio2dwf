package sv.edu.udb.desafio2_dwf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Desafio2DwfApplicationTests {

    @Test
    void contextLoads() {
    }

}
