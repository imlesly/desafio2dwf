
package sv.edu.udb.desafio2_dwf.controller;

import sv.edu.udb.desafio2_dwf.domain.*;
import sv.edu.udb.desafio2_dwf.domain.Client;
import sv.edu.udb.desafio2_dwf.domain.Invoice;
import sv.edu.udb.desafio2_dwf.dto.InvoiceRequest;
import sv.edu.udb.desafio2_dwf.repository.*;
import sv.edu.udb.desafio2_dwf.repository.ClientRepository;
import sv.edu.udb.desafio2_dwf.repository.InvoiceRepository;
import sv.edu.udb.desafio2_dwf.service.InvoiceService;

import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/clients/{clientId}/invoices")
public class InvoiceController {

    private final ClientRepository clientRepo;
    private final InvoiceRepository invoiceRepo;
    private final InvoiceService service;

    public InvoiceController(ClientRepository clientRepo, InvoiceRepository invoiceRepo, InvoiceService service) {
        this.clientRepo = clientRepo;
        this.invoiceRepo = invoiceRepo;
        this.service = service;
    }

    @PostMapping
    public Invoice create(@PathVariable Long clientId, @Valid @RequestBody InvoiceRequest req) {
        Client client = clientRepo.findById(clientId)
            .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        Invoice invoice = new Invoice();
        invoice.setMonto(req.getMonto());
        invoice.setClient(client);

        return invoiceRepo.save(service.calcular(invoice));
    }
}
