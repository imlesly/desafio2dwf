
package sv.edu.udb.desafio2_dwf.domain;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Data
public class Client {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String email;
    private String documento;

    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL)
    private List<Invoice> invoices;
}
