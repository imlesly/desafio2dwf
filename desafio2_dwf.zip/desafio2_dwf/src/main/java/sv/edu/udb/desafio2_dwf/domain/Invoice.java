
package sv.edu.udb.desafio2_dwf.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
public class Invoice {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double monto;
    private double iva;
    private double total;

    @ManyToOne
    private Client client;
}
