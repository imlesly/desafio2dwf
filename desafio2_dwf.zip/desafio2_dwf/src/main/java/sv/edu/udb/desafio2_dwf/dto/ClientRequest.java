
package sv.edu.udb.desafio2_dwf.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
public class ClientRequest {
    @NotBlank
    private String nombre;

    @Email
    private String email;

    @NotBlank
    private String documento;
}
