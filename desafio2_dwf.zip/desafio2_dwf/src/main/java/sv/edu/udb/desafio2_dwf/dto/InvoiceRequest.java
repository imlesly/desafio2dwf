
package sv.edu.udb.desafio2_dwf.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
public class InvoiceRequest {
    @Positive
    private double monto;
}
