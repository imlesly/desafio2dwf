
package sv.edu.udb.desafio2_dwf.repository;

import sv.edu.udb.desafio2_dwf.domain.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client, Long> {}
