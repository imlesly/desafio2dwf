
package sv.edu.udb.desafio2_dwf.repository;

import sv.edu.udb.desafio2_dwf.domain.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {}
