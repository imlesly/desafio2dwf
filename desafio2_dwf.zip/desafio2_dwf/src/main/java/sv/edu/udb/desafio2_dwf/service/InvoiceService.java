
package sv.edu.udb.desafio2_dwf.service;

import sv.edu.udb.desafio2_dwf.domain.Invoice;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService {

    public Invoice calcular(Invoice invoice) {
        double iva = invoice.getMonto() * 0.13;
        invoice.setIva(iva);
        invoice.setTotal(invoice.getMonto() + iva);
        return invoice;
    }
}
