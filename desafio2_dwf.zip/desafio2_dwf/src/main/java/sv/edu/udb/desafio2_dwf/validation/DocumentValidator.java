
package sv.edu.udb.desafio2_dwf.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DocumentValidator implements ConstraintValidator<ValidDocument, String> {
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.isBlank()) {
            return false;
        }

        // Validamos el formato de un DUI (8 dígitos - 1 dígito) o un NIT (4 dígitos )
        boolean isDui = value.matches("^\\d{8}-\\d$");
        boolean isNit = value.matches("^\\d{4}-\\d$");

        return isDui || isNit;
    }
}
